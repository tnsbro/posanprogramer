from flask import Flask, render_template, request, redirect, url_for, session
from pymongo import MongoClient
from datetime import datetime

app = Flask(__name__)
app.secret_key = 너의 시크릿 키

# MongoDB 클라이언트 연결
client = MongoClient(여기 채우기)
db = client["community_db"]
users_collection = db["users"]  
posts_collection = db["posts"]  

@app.route('/')
def index():
    posts = posts_collection.find()
    return render_template("index.html", posts=posts)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = {
            "username": username,
            "password": password,
            "created_at": datetime.now()
        }
        users_collection.insert_one(user)
        return redirect(url_for('login'))
    return render_template("register.html")

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = users_collection.find_one({"username": username, "password": password})
        if user:
            session['username'] = username
            return redirect(url_for('index'))
        else:
            return "아이디 또는 비밀번호가 틀렸습니다."
    return render_template("login.html")

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('index'))

@app.route('/create_post', methods=['GET', 'POST'])
def create_post():
    if 'username' not in session:
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        title = request.form['title']
        content = request.form['content']
        post = {
            "username": session['username'],
            "title": title,
            "content": content,
            "created_at": datetime.now()
        }
        posts_collection.insert_one(post)
        return redirect(url_for('index'))
    
    return render_template("create_post.html")

if __name__ == "__main__":
    app.run(debug=True)
