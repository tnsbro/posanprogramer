from flask import Flask, request, render_template, redirect, url_for
from pymongo import MongoClient
from werkzeug.utils import secure_filename
import os

app = Flask(__name__)

client = MongoClient(여기 채우기) 
db = client['youtube_clone']
videos_collection = db['videos'] 

app.config['UPLOAD_FOLDER'] = 'uploads/videos'
app.config['ALLOWED_EXTENSIONS'] = {'mp4', 'avi', 'mov', 'mkv'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

@app.route('/')
def index():
    videos = videos_collection.find() 
    return render_template('index.html', videos=videos)

@app.route('/upload', methods=['GET', 'POST'])
def upload():
    if request.method == 'POST':
        if 'video' not in request.files:
            return redirect(request.url)
        file = request.files['video']
        if file.filename == '':
            return redirect(request.url)
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))

            video_data = {
                'title': request.form['title'],
                'description': request.form['description'],
                'filename': filename
            }
            videos_collection.insert_one(video_data)  
            return redirect(url_for('index'))
    return render_template('upload.html')

@app.route('/video/<video_id>')
def video(video_id):
    video = videos_collection.find_one({'_id': MongoClient.ObjectId(video_id)})
    if not video:
        return "Video not found", 404
    return render_template('video.html', video=video)

if __name__ == '__main__':
    if not os.path.exists(app.config['UPLOAD_FOLDER']):
        os.makedirs(app.config['UPLOAD_FOLDER'])
    app.run(debug=True)
